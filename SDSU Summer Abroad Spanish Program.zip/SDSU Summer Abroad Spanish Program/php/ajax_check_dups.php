<?php

/* Venkatesh Peddi, FNU Account: jadrn046

Project 2b  */

require_once ('phpHelper.php');


if(isDup($_POST))
    echo 'DUP';
else
    echo 'OK';
?>
