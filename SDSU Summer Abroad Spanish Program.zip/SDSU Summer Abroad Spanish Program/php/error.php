<?php

/* Venkatesh Peddi, FNU Account: jadrn046

Project 2b  */


 echo 'Please enable javascript on your browser for this application to function
 properly';
?>
