This is a web site that lets users sign their children for the fictitious SDSU Summer Abroad Spanish Program. Children between the ages of 12 and 18 may enroll in a six week language and cultural immersion program in Guanajuato, Mexico.

The parent can enroll their children for this program by filling up the registration form.

Information about the  SDSU Summer Abroad Spanish school, the programs offered and reviews are available in the website. It can be accessed using the navigation menus.

Also an authorized user will be able to access the All participants and
Participants per program report.
